import 'package:flutter/material.dart';

const textColor = Color(0xFF535353);
const textLightColor = Color(0xFFACACAC);

const padding = 20.0;
